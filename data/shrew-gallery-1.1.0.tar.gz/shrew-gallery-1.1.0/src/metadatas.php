<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class Metadatas {
  public $count;
  public $date;
  public $model;
  public $focalLength;
  public $exposure;
  public $focale;
  public $iso;
  public $flash;
  
  function Load($path)
  {
    
    //init
    $this->count = 0;
    $this->model ='';
    $this->date ='';
    $this->focalLength = '';
    $this->exposure='';
    $this->focale='';
    $this->iso='';
    $flash=false;
    
    if(!$this->IsExifAvailable()){return;}
  /*  
    echo "$path:<br />\n";
    
    echo $exif===false ? "Aucun en-tête de donnés n'a été trouvé.<br />\n" : "L'image contient des en-têtes<br />\n";
*/
    /*$exif = exif_read_data($path, 0, true);
    echo "$path:<br />\n";
    foreach ($exif as $key => $section) {
        foreach ($section as $name => $val) {
            echo "$key.$name: $val<br />\n";
      }
    }*/
    
    $ifd0 = exif_read_data($path, 'IFD0');
    
    if($ifd0 !== false){
    
      //Model
      if(array_key_exists('Model',$ifd0)){
        if($ifd0['Model'] == 'NIKON D90'){
          $this->model = 'Nikon D90';
        }elseif($ifd0['Make'] == 'Canon'){
          $this->model = $ifd0['Model'];
        }
		else{
          $this->model = $ifd0['Make'].' '.$ifd0['Model'];
        }
        $this->count++;
      }
      
      //date
      if(array_key_exists('DateTime',$ifd0)){
        $this->date = $ifd0['DateTime'];
        $this->count++;
      }
    }
    
    $exif = exif_read_data($path, 'EXIF');
    
    if($exif !== false){
    
    
      //FocalLength
      if(array_key_exists('FocalLength',$exif)){
        $this->focalLength = $exif['FocalLength'];
        if(preg_match('#^([0-9]+)/([0-9]+)$#i',$this->focalLength)){
          $num = preg_replace('#^([0-9]+)/([0-9]+)$#i','$1',$this->focalLength);
          $den = preg_replace('#^([0-9]+)/([0-9]+)$#i','$2',$this->focalLength);
          $this->focalLength = ($num/$den).'mm';
        }
        $this->count++;
      }
      
      //Exposure time
      if(array_key_exists('ExposureTime',$exif)){
        $this->exposure = $exif['ExposureTime'];
        if(preg_match('#^([0-9]+)/([0-9]+)$#i',$this->exposure)){
          $num = preg_replace('#^([0-9]+)/([0-9]+)$#i','$1',$this->exposure);
          $den = preg_replace('#^([0-9]+)/([0-9]+)$#i','$2',$this->exposure);
          if($num<$den){
            $this->exposure = '1/'.($den/$num);
          }
          $this->exposure = $this->exposure.'s';
        }
        $this->count++;
      }
      
      //Focale
      if(array_key_exists('FNumber',$exif)){
        $this->focale = $exif['FNumber'];
        if(preg_match('#^([0-9]+)/([0-9]+)$#i',$this->focale)){
          $num = preg_replace('#^([0-9]+)/([0-9]+)$#i','$1',$this->focale);
          $den = preg_replace('#^([0-9]+)/([0-9]+)$#i','$2',$this->focale);
          $this->focale = ($num/$den);
        }
        $this->focale = 'f/'.$this->focale;
        $this->count++;
      }
      
      //ISO
      if(array_key_exists('ISOSpeedRatings',$exif)){
        $this->iso = 'ISO '.$exif['ISOSpeedRatings'];
        
        $this->count++;
      }
      
      //Flash
      if(array_key_exists('Flash',$exif)){
        if($exif['Flash'] != 0){
          $this->flash = true;
        }
        
        $this->count++;
      }
      
      
    }
    
    
  }
  
  
  function IsExifAvailable()
  {
      if (extension_loaded('exif')) {
        return true;
      }else{
        return false;
      }
      
  } 
}

?>
