#!/bin/sh
#Prepare photos for shrew-gallery
#Need imagemagick
for img in `ls *.jpg`
do
	thumb=`echo $img| sed 's/^\(.*\).jpg$/\1-thumb.jpg/'`
	
	convert $img -resize 800x $thumb
	convert $thumb -auto-orient $thumb
	convert $img -auto-orient $img
done		
