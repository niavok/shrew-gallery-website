<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class LinkManager{
 private $album;
 private static $instance;
  
  static function SetInstance($instance){
    self::$instance = $instance;
  }
  
  static function GetInstance(){
    return self::$instance;
  }
 
  public function SetAlbum($album){
    $this->album = $album;
  }
 
 public function Generate(){
   return "index.php?path=".$this->album->GetPath();
 }
 
 public function GenerateParent(){
   return "index.php?path=".$this->album->GetParentPath();
 }
 
 public function GenerateWant($want){
   return $this->Generate().'&want='.$want;
 }
 
 public function GeneratePath($path){
   return "index.php?path=".$path;
 }
 
}

?>
