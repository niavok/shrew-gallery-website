<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class MediaManager {
  function GetMedias($path)
  {
    $dir = opendir($path);
    $medias = array();
	$files = array();
	while(false !== ($f = readdir($dir))) {
	    if($f != '..' && is_file($path.'/'.$f)) {
			$files[] = $f;
		}
	}
	
	sort($files);
	
	foreach($files as $f){
         if($this->IsImage($path.'/'.$f))
         {
           $image = new Image();
           $image->SetPath($path.'/'.$f);
           $medias[] = $image;
         }
         if($this->IsVideo($path.'/'.$f))
         {
           $video = new Video();
           $video->SetPath($path.'/'.$f);
           $medias[] = $video;
         }
         
         if($this->IsAudio($path.'/'.$f))
         {
           $audio = new Audio();
           $audio->SetPath($path.'/'.$f);
           $medias[] = $audio;
         }
       }
   
    closedir($dir);
    return $medias;
  }
  
  function IsImage($f)
  {
    $is_image = false;
    if(preg_match('#.jpg$#i',$f))
    {
      $is_image = true;
    }
  
    if(preg_match('#.bmp$#i',$f))
    {
      $is_image = true;
    }
   
    if(preg_match('#.png$#i',$f))
    {
      $is_image = true;
    }
    
    if(preg_match('#.jpeg$#i',$f))
    {
      $is_image = true;
    }
    
    if($is_image){
      if(preg_match('#^(.*)-thumb\.([0-9a-wA-Z])#',$f)){
        //Is thumb
        $is_image = false;
      }
    }
    return $is_image;

  }
  function IsVideo($f)
  {
    $is_video = false;
    if(preg_match('#.ogv$#i',$f))
    {
      $is_video = true;
    }
    
    if(preg_match('#.ogg$#i',$f))
    {
      $is_video = true;
    }
    
    
    if($is_video){
      $ogg = new Ogg($f);
      $is_video = ($ogg->GetCodec() == 'theora' || $ogg->GetCodec()=='ishead');
    }

    
    return $is_video;

  }
  
  function IsAudio($f)
  {
    $is_audio = false;
    
    if(preg_match('#.oga$#i',$f))
    {
      $is_audio = true;
    }
    
    if(preg_match('#.ogg$#i',$f))
    {
      $is_audio = true;
    }
    
    if($is_audio){
      $ogg = new Ogg($f);
      $is_audio = ($ogg->GetCodec() == 'vorbis');
    }
    
    return $is_audio;

  }
  
  
  
  
}

?>
