<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class Config {
  private static $instance;
  public $path = '.';       
  public $licenceFileName = 'licence.txt';
  public $version = '1.1.1';
  
  static function SetInstance($instance){
    self::$instance = $instance;
  }
  
  static function GetInstance(){
    return self::$instance;
  }
  
  function Load()
  {
    if(isset($_GET['path']))
    {
	  if(preg_match('!^\.(/[a-zA-Z0-9]+)*$!',$_GET['path'])){
        $this->path = $_GET['path'];
	  }
    }	    
  }
  
  function GetScriptName(){
    return $_SERVER['SCRIPT_NAME'];
  }
  
  function GetPath(){
	return $this->path;
  }
}

?>
