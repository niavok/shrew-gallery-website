<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class Image extends Media{
  
  function __construct(){
    $this->SetType('image');
  }
    
  function GetWidth(){
    $size = getimagesize($this->GetPath());
    return $size[0];
  }
  
  function GetHeight(){
    $size = getimagesize($this->GetPath());
    return $size[1];
  }
  
  function GetThumb(){
    $name = preg_replace('!^(.*)(\.[a-zA-Z0-9]+)$!','$1',$this->GetPath());
    $extension = preg_replace('!^(.*)(\.[a-zA-Z0-9]+)$!','$2',$this->GetPath());
   
     if(file_exists($name.'-thumb'.$thumbIndex.$extension)){
        $thumb = new Image();
        $thumb->SetPath($name.'-thumb'.$thumbIndex.$extension);
        return $thumb;
    }else{
		return $this;
	}
   
  }
}

?>
