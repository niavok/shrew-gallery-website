<?php
// Access rules example
// Leave '//'. It permit to hide the content of this file


//access test-login1 test-password1
//access test-login2 test-password2
//access test-login3 test-password3
//access test-login4 test-password4

//group test-group1 test-login1 test-login2

//rule . public
//rule ./album1 test-login1
//rule ./album2 test-group1 test-login3
//rule ./album2/album2.2 test-login3

// The album './album3' has the default
// access rules : test-login1 test-login2 test-login3 test-login4.
// The album './album2/album2.1' has the access rules of parent album. 
?>
