<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class Album {
  private $m_path='.';
  function GetPath()
  {
    return $this->m_path;
  }

  function GetParentPath(){
  	if($this->m_path == '.'){
		return;
    }
    return preg_replace('!^(.*)/([-a-zA-Z_.]+)$!','$1',$this->m_path);
  }
  
  function SetPath($path)
  {
    $this->m_path = $path;
  }

  function GetName()
  {
	return preg_replace('!^\./(.*)$!','$1',$this->m_path);
  }

  function GetMediaCount()
  {
    $mediaManager = new MediaManager();
    $medias = $mediaManager->GetMedias($this->m_path);
    return count($medias);

  }
  
  function GetImageCount()
  {
    return count($this->GetImages());
  }
  
  function GetVideoCount()
  {
    return count($this->VideoImages());
  }

  function GetTotalMediaCount()
  {
    $count = $this->GetMediaCount();
    $albumManager = new AlbumManager();
    $childAlbums = $this->GetChildAlbums();
    foreach($childAlbums as $album){
      $count += $album->GetTotalMediaCount();
    }
    return $count;
  }
  
  function GetTotalImageCount()
  {
    $count = $this->GetImageCount();
    $albumManager = new AlbumManager();
    $childAlbums = $this->GetChildAlbums();
    foreach($childAlbums as $album){
      $count += $album->GetImageCount();
    }
    return $count;
  }
  
  function GetTotalVideoCount()
  {
    $count = $this->GetVideoCount();
    $albumManager = new AlbumManager();
    $childAlbums = $this->GetChildAlbums();
    foreach($childAlbums as $album){
      $count += $album->GetVideoCount();
    }
    return $count;
  }

  function GetMedias()
  { 
    $mediaManager = new MediaManager();
    return $mediaManager->GetMedias($this->m_path);
  }
  
  function GetImages(){
    $medias = $this->GetMedias();
    $images = array();
    foreach($medias as $media){
      if($media->GetType() == 'image'){
        $images[] = $media;
      }
    }
    return $images;
  }

  function GetVideos(){
    $medias = $this->GetMedias();
    $videos = array();
    foreach($medias as $media){
      if($media->GetType() == 'video'){
        $videos[] = $media;
      }
    }
    return $videos;
  }

  function GetAudios(){
    $medias = $this->GetMedias();
    $audios = array();
    foreach($medias as $media){
      if($media->GetType() == 'audio'){
        $audios[] = $media;
      }
    }
    return $audios;
  }  

  
  function GetChildAlbums()
  {
    $albumManager = new AlbumManager();
    return $albumManager->GetAlbums($this->GetPath());
  }
  
  function GetDescription()
  {
    $out = '';
    $images = $this->GetImages();
    $videos = $this->GetVideos();
    $audios = $this->GetAudios();
    $albums = $this->GetChildAlbums();
    
    $texts = array();
             
    if(count($images)>0){
        $texts[] = count($images).' image'.(count($images)>1?'s':'');
    }
    
    if(count($videos)>0){
        $texts[] = count($videos).' video'.(count($videos)>1?'s':'');
    }
    
    if(count($audios)>0){
        $texts[] = count($audios).' musique'.(count($audios)>1?'s':'');
    }
    
    
    if(count($this->GetChildAlbums()) > 0) {
      $albumDesc = count($albums).' album'.(count($this->GetChildAlbums())>1?'s':'');
      if($this->GetTotalImageCount()-$this->GetImageCount() != 0){
        $albumDesc .= ' ('.$this->GetTotalMediaCount().' élément'.($this->GetTotalMediaCount()>1?'s':'').')';
      }
      $texts[] = $albumDesc;
    }
    
    if(count($texts) ==0)
    {
      $out = 'album vide';
    }else{
      for($i =0; $i < count($texts); $i++){
        $out.=$texts[$i];
        if($i < count($texts) -2){
          $out.=', ';
        }
        if($i == count($texts)-2){
          $out.=' et ';
        }
        
      }
    }
    
    return $out;
  }
  
  function GetParent(){
    $album = new Album();
    $album->SetPath($this->GetParentPath());
    return $album;
  }
  
  function IsLicence(){
    
    if(file_exists($this->GetPath().'/'.Config::GetInstance()->licenceFileName)){
      if($this->ReadLicence() == ''){
        return false;
      }else{
        return true;
      }
    }elseif($this->IsRootAlbum()){
      return false;
    }else{
      return $this->GetParent()->IsLicence();
    }
  }
  
  function GetLicence(){
    if(file_exists($this->GetPath().'/'.Config::GetInstance()->licenceFileName)){
      return $this->ReadLicence();
    }elseif($this->IsRootAlbum()){
      return '';
    }else{
      return $this->GetParent()->ReadLicence();
    }
  }
  
  function ReadLicence(){
    $licence = '';
    $file = fopen($this->GetPath().'/'.Config::GetInstance()->licenceFileName,"r");

    while ($line = fgets($file))
    {
      $licence .=$line;
    }

    fclose($file);
    
    return $licence;
  }

  function IsRootAlbum(){
    return ($this->GetPath() == '.');
  }
}

?>
