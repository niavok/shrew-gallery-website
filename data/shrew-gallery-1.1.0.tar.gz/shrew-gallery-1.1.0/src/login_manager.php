<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class LoginManager {
  private $loginList = array();
  private $passwordList = array();
  private $rulesList = array();
  private $rulesMembersList = array();
  private $groupList = array();
  private $groupMembersList = array();
  
  private $login = 'public';
  private $access_locked = false;
  
  private static $instance;
  
  static function SetInstance($instance){
    self::$instance = $instance;
  }
  
  static function GetInstance(){
    return self::$instance;
  }
 
  public function SetAlbum($album){
    $this->album = $album;
  }
  
  function WantLogin(){
    if(!isset($_GET['want']))
    {
      return false;
    }
    return ($_GET['want'] == 'login');
  }
  
  function WantLogout(){
    if(!isset($_GET['want']))
    {
      return false;
    }
    
    return ($_GET['want'] == 'logout');
  }
 
  function IsLogged(){
    if($this->login == 'public'){
      return false;
    }else{
      return true;
    }
  }
  
  function TryLogin(){
    $login = $_POST['login'];
    $password = $_POST['password'];
    $success = false;
    $this->login = 'public';

    if(($pos = array_search($login,$this->loginList)) !==false)
    {
      if($this->passwordList[$pos] == $password)
      {
        $success = true;
        $_SESSION[$this->GetLoginSessionKey()] = $login;
        $this->login = $login; 
      }
      
    }

    return $success;
  }
  
  function Logout()
  {
    session_destroy();
    $_SESSION[$this->GetLoginSessionKey()] = 'public'; 
    $this->login = 'public';
  }
  
  function Load(){
    session_start();
    if(file_exists("access.php"))
    {
      $conf_file = fopen("access.php", "r");
      $this->access_locked = true;
      while($ligne = fgets($conf_file))
      {
        
        //Load access
        if(preg_match("#^//access ([-_a-zA-Z0-9]+) ([-_a-zA-Z0-9]+)$#", $ligne))
        {
          $ligne = str_replace("\n", "", $ligne); 
          $login = preg_replace("#^//access ([-_a-zA-Z0-9]+) ([-_a-zA-Z0-9]+)$#",'$1',$ligne);
          $password = preg_replace("#^//access ([-_a-zA-Z0-9]+) ([-_a-zA-Z0-9]+)$#",'$2',$ligne);
          $this->loginList[] = $login;
          $this->passwordList[] = $password;
          continue;
        }
        
        //Load group
        if(preg_match("#^//group ([-_a-zA-Z0-9]+)( ([-_a-zA-Z0-9]+))*$#", $ligne))
        {
          $ligne = str_replace("\n", "", $ligne); 
          $group = preg_replace("#^//group ([-_a-zA-Z0-9]+)( ([-_a-zA-Z0-9]+))*$#",'$1',$ligne);
          $this->groupList[] = $group;
          
          $groupMembers = array();
          $groupMembersLine = preg_replace("#^//group ([-_a-zA-Z0-9]+)(( ([-_a-zA-Z0-9]+))*)$#",'$2',$ligne);
          
          while($groupMembersLine != ''){
            $groupMembers[] = preg_replace("#^ ([-_a-zA-Z0-9]+)(( ([-_a-zA-Z0-9]+))*)$#",'$1',$groupMembersLine);
            
            $groupMembersLine = preg_replace("#^ ([-_a-zA-Z0-9]+)(( ([-_a-zA-Z0-9]+))*)$#",'$2',$groupMembersLine);          
          }
          
          $this->groupMembersList[$group] = $groupMembers;
          continue;
        }
        
        //Load rule
        if(preg_match("#^//rule ([-_./a-zA-Z0-9]+)( ([-_a-zA-Z0-9]+))*$#", $ligne))
        {
          $ligne = str_replace("\n", "", $ligne); 
          $rule = preg_replace("#^//rule ([-_./a-zA-Z0-9]+)( ([-_a-zA-Z0-9]+))*$#",'$1',$ligne);
          $this->rulesList[] = $rule;
          $ruleMembers = array();
          if(preg_match("#^//rule ([-_./a-zA-Z0-9]+)( ([-_a-zA-Z0-9]+))+$#", $ligne)){
            $ruleMembersLine = preg_replace("#^//rule ([-_./a-zA-Z0-9]+)(( ([-_a-zA-Z0-9]+))+)$#",'$2',$ligne);
            while($ruleMembersLine != ''){
              $ruleMembers[] = preg_replace("#^ ([-_a-zA-Z0-9]+)(( ([-_a-zA-Z0-9]+))*)$#",'$1',$ruleMembersLine);
              
              $ruleMembersLine = preg_replace("#^ ([-_a-zA-Z0-9]+)(( ([-_a-zA-Z0-9]+))*)$#",'$2',$ruleMembersLine);          
            }
          }
          
          $this->rulesMembersList[$rule] = $ruleMembers;
          continue;
        }
        
      }
     
      fclose($conf_file);
    } else {
      $this->access_locked = false;
    }
    
    //Load current session
    if(isset($_SESSION[$this->GetLoginSessionKey()])){
      $this->login = $_SESSION[$this->GetLoginSessionKey()];
    }else{
      $this->login = 'public';
    }
  }
  
  function GetLoginSessionKey()
  {
    $key = 'login_'.__FILE__;
   return $key;
  }
  
  function IsAccessAllowed($album)
  {
    //Test if access file control access
    if($this->access_locked)
    {
      //Access restricted
      if($this->IsRule($album->GetPath()))
      {
        //Custom access rules
        $accessList = $this->GetRule($album->GetPath());
        if(count($accessList) == 0){
          //Access forbidden for all
          return false;
        }
        if(count($accessList) == 1 && $accessList[0] == 'public'){
          //Access allowed for all
          return true;
        }
        $accessLogin = $this->ExpandGroups($accessList);
        if(in_array($this->login,$accessLogin)){
          //Login found
          return true;
        }else{
          //Login not match
          return false;
        }
      }else{
        
        if($album->GetPath() == '.'){
          //Use default access
          if(count($this->loginList) > 0) {
            //Need login
            if($this->login == 'public'){
              //Not logged
              return false;
            }else{
              if(in_array($this->login,$this->loginList)){
                //Login found
                return true;
              }else{
                //Login not match
                return false;
              }
            }
            
          }else{
            //Nobody can acess
            return false;
          }
        }else{
          //Use the parent access rules
          return $this->IsAccessAllowed($album->GetParent());
        }
      }
    }else{
      //Public Access
      return true;
    }
  }
  
  function IsRule($path){
    if(in_array($path,$this->rulesList)){
      return true;
    }else{
      return false;
    }
  }
  
  function GetRule($path){
    return $this->rulesMembersList[$path];
  }
  
  function ExpandGroups($groups){
    $accessList = array();
    foreach($groups as $group){
      $accessList = array_merge($accessList,$this->ExpandGroup($group));
    }
    return $accessList;
  }
  
  function ExpandGroup($group){
    
    $accessList = array();
    
    if(!in_array($group,$this->groupList)){
      $accessList[] = $group; 
    }else{    
      foreach($this->groupMembersList[$group] as $groupMember)
      {
        if(in_array($groupMember,$this->groupList)){
          $groupContent = $this->ExpandGroup($groupMember);
          $accessList = array_merge($accessList,$groupContent);
        }else{
          $accessList[] = $groupMember;
        } 
      }
    }
    return $accessList;
  }

  function GetCurrentLogin(){
    return $this->login;
  }
}

?>
