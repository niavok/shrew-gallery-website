<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class DisplayManager {
  public $currentAlbum;
  public $childAlbumList;  
  function DisplayImagesPage($album)
  {
    $this->currentAlbum = $album;
    $this->childAlbumList = $album->GetChildAlbums();
    $this->PrintHtmlHeader();
    $this->PrintImagesPageHeader();
    $this->PrintAlbumsPageBody();
    $this->PrintImagesPageBody();
    $this->PrintFooter();
  }
  
  function DisplayLoginPage($album,$loginFail)
  {
    $this->currentAlbum = $album;
    $this->PrintHtmlHeader();
    $this->PrintLoginForm($loginFail);
    $this->PrintFooter();
  }
  
  function DisplayAccessRefusedPage($album){
    $this->currentAlbum = $album;
    $this->PrintHtmlHeader();
    $this->PrintAccessRefusedPageBody();
    $this->PrintFooter();
  }
  
  function DisplayHelpPage(){
    $this->PrintHtmlHeader();
    $this->PrintHelpPageBody();
    $this->PrintFooter();
  }
  
  function PrintHtmlHeader()
  {  
    $style = new Style();
    echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">'."\n";
    echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >'."\n";
    echo '  <head>'."\n";
    echo '    <title>Shrew Gallery</title>'."\n";
    echo '    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'."\n";
    echo '<style type="text/css">'."\n";
    echo $style->Generate();
    echo '</style>'."\n";
    echo '  </head>'."\n";
    echo '  <body>'."\n";
    echo '  <div id="page">'."\n";
    echo '<div id=top_menu>'."\n";
    
    if($this->currentAlbum && $this->currentAlbum->GetPath() != '.'){
            echo '  <a href="'.LinkManager::GetInstance()->GenerateParent().'" >Album parent</a> '."\n";
    }
    if(LoginManager::GetInstance()->GetCurrentLogin() != 'public')
    {
      echo '    <a href="'.LinkManager::GetInstance()->GenerateWant('logout').'" >Déconnection ('.LoginManager::GetInstance()->GetCurrentLogin().')</a>'."\n";
    }
    echo '</div>'."\n";
    echo '    <h1>Shrew gallery</h1>'."\n";
  }
  
  function PrintFooter()
  {
    echo '      <div id="footer">'."\n";
    echo '        <p id="copyright" ></p>Powered by <a href="http://shrew-gallery.b219.org" >Shrew-gallery v'.Config::GetInstance()->version.'</a> - Copyright (C) 2009 Frédéric Bertolus</p>'."\n";
    echo '        <p id="licence" >Shrew-gallery is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.</p>'."\n";
    echo '        <p id="source" ></p>The source code can be found at the following URL : <a href="'.LinkManager::GetInstance()->GenerateWant('source').'">'.Config::GetInstance()->GetScriptName().'</a></p>'."\n";
    echo '      </div>'."\n";//div footer
    echo '    </div>'."\n";//div page
    echo '  </body>'."\n";
    echo '</html>';
  }
  
  function PrintImagesPageHeader()
  {
    $medias = $this->currentAlbum->GetMedias();
    if(count($medias)>0 || count($this->childAlbumList) > 0)
    { 
            echo '<p>Cet album contient ';
            echo $this->currentAlbum->GetDescription();
            echo '. ';
            if(file_exists($this->currentAlbum->GetPath().'/all.zip')){
                echo '<br /><br />Vous pouvez télécharger l\'intégralité de cet album en suivant ce lien : <a href='.$this->currentAlbum->GetPath().'/all.zip >all.zip</a>.';
            }
            echo '</p>'."\n";
    } else {
      echo '      <div  class="image-bloc">'."\n";
      echo '        Cet album est vide.'."\n";
      echo '      </div>'."\n";//div image
    }
  }
  
  function PrintImagesPageBody()
  {
    $medias = $this->currentAlbum->GetMedias();
    if($medias)
    {
      $start = 0;
      $count = 8;
      if(isset($_GET['start']))
      {
        $start = $_GET['start'];
      }
      
      if($start <0) { $start = 0;}
      if($start >=count($medias)) { $start = count($medias)-1;}
      
      
      if(isset($_GET['count']))
      {
        $count = $_GET['count'];
      }
      $end = $start+$count;
      
      if($end <0) { $end = 0;}
      if($end >count($medias)) { $end = count($medias);}
      
      
      echo '<p><form action="'.LinkManager::GetInstance()->Generate().'" method="get">Élements par page : <input name=start type=hidden value="'.$start.'"/><input name=path type=hidden value="'.$this->currentAlbum->GetPath().'"/><input type=text name=count size=2 value="'.$count.'"/> <input type=submit value=OK /></form></p>'."\n";
      
      for($index = $start; $index < $end; $index++)
      {
        // Print each media
        if($medias[$index]->GetType() == 'image')
        {
          $this->DisplayImage($medias,$index,$count,$start,$end);
        }
        
        if($medias[$index]->GetType() == 'video')
        {
          $this->DisplayVideo($medias,$index,$count,$start,$end);
        }
        
         if($medias[$index]->GetType() == 'audio')
        {
          $this->DisplayAudio($medias,$index,$count,$start,$end);
        }
        
      }
      
      if($this->currentAlbum->IsLicence()){
        echo '        <div class="licence">'."\n";
        echo '        <p>'.$this->currentAlbum->GetLicence().'</p>'."\n";
        echo '        </div>'."\n";
      }
      
    }
   
  }
  
  function DisplayImage($medias,$index,$count,$start,$end){
    $images = $medias;
    $image = $medias[$index];
        echo '      <div id="image-'.$index.'" class="image-bloc">'."\n";
        echo '        <div class="image-infos-bloc">'."\n";
        echo '        <div class="image-infos">'."\n";
        echo '          <h1>Image - '.($index+1).' sur '.count($images).'</h1>'."\n";
        echo '          <ul>'."\n";
        echo '           <li><a href="'.$image->GetPath().'" >Original</a></li>'."\n";
        echo '          </ul>'."\n";
        echo '        </div>'."\n";
        $this->DisplayControls($medias,$index,$count,$start,$end);//Metadatas
        $metadatas = $image->GetMetadatas();
        if($metadatas->count > 0){
          echo '        <div class="image-infos">'."\n";
          echo '          <h1>Métadonnées</h1>'."\n";
          echo '          <ul>'."\n";
          if($metadatas->date != '') {
            echo '           <li>'.$metadatas->date.'</li>'."\n";
          }
          if($metadatas->model != '') {
            echo '           <li>'.$metadatas->model.'</li>'."\n";
          }
          if($metadatas->focalLength != '') {
            echo '           <li>'.$metadatas->focalLength.'</li>'."\n";
          }
          if($metadatas->exposure != '') {
            echo '           <li>'.$metadatas->exposure.'</li>'."\n";
          }
          if($metadatas->focale != '') {
            echo '           <li>'.$metadatas->focale.'</li>'."\n";
          }
          if($metadatas->iso != '') {
            echo '           <li>'.$metadatas->iso.'</li>'."\n";
          }
          if($metadatas->flash == true) {
            echo '           <li>Flash</li>'."\n";
          }
          
          echo '          </ul>'."\n";
          echo '        </div>'."\n";
        }
         
        echo '        </div>'."\n";    
        //Display image
        echo '        <div class="image">'."\n";
		$width = $image->GetThumb()->GetWidth();
        echo '        <img src="'.$image->GetThumb()->GetPath().'" width='.($width>800?'800':$width).'px />'."\n";
        echo '        </div>'."\n";
        echo '      </div>'."\n";//div image
  }


function DisplayVideo($medias,$index,$count,$start,$end){
    $images = $medias;
    $video = $medias[$index];
        echo '      <div id="image-'.$index.'" class="image-bloc">'."\n";
        echo '        <div class="image-infos-bloc">'."\n";
        echo '        <div class="image-infos">'."\n";
        echo '          <h1>Video - '.($index+1).' sur '.count($images).'</h1>'."\n";
        echo '          <ul>'."\n";
        echo '           <li><a href="'.$video->GetPath().'" >Original</a></li>'."\n";
        echo '          </ul>'."\n";
        echo '        </div>'."\n";
        $this->DisplayControls($medias,$index,$count,$start,$end);
        echo '        </div>'."\n";    
        //Display video
        echo '        <div class="video">'."\n";
        echo '        <video controls=true src="'.$video->GetPath().'">Votre navigateur ne respecte pas suffisement les standards. Vous pouvez néanmoins téléchager la vidéo ici : <a href="'.$video->GetPath().'" >Original</a></video>'."\n";
        echo '        </div>'."\n";
        echo '      </div>'."\n";//div video
  }
  
  function DisplayAudio($medias,$index,$count,$start,$end){
    $images = $medias;
    $audio = $medias[$index];
        echo '      <div id="image-'.$index.'" class="image-bloc">'."\n";
        echo '        <div class="image-infos-bloc">'."\n";
        echo '        <div class="image-infos">'."\n";
        echo '          <h1>Musique - '.($index+1).' sur '.count($images).'</h1>'."\n";
        echo '          <ul>'."\n";
        echo '           <li><a href="'.$audio->GetPath().'" >Original</a></li>'."\n";
        echo '          </ul>'."\n";
        echo '        </div>'."\n";
        $this->DisplayControls($medias,$index,$count,$start,$end);
         
        echo '        </div>'."\n";    
        //Display audio
        echo '        <div class="video">'."\n";
        echo '        <audio controls=true src="'.$audio->GetPath().'">Votre navigateur ne respecte pas suffisement les standards. Vous pouvez néanmoins téléchager ce fichier ici : <a href="'.$audio->GetPath().'" >Original</a></audio>'."\n";
        echo '        </div>'."\n";
        echo '      </div>'."\n";//div video
  }


  function DisplayControls($medias,$index,$count,$start,$end){
    echo '        <div class="image-infos">'."\n";
        echo '          <ul>'."\n";
        echo '           <li><a href="#page" >Haut de la page</a></li>'."\n";
        if($index>0){
          echo '           <li><a href="#image-'.($index-1).'" >Élément précédent</a></li>'."\n";
        }
        if($index<($end-1)){
          echo '           <li><a href="#image-'.($index+1).'" >Élément suivant</a></li>'."\n";
        }
        echo '           <li><a href="#footer" >Bas de la page</a></li>'."\n"; 
        echo '          </ul>'."\n";
        echo '          <ul>'."\n";
        
        if($start>0){
          echo '           <li><a href="'.LinkManager::GetInstance()->Generate().'&count='.$count.'" >Première page</a></li>'."\n";
          echo '           <li><a href="'.LinkManager::GetInstance()->Generate().'&start='.($start-$count).'&count='.$count.'" >Page précédente</a></li>'."\n";
        }
        if($end<count($medias)){
          echo '           <li><a href="'.LinkManager::GetInstance()->Generate().'&start='.($start+$count).'&count='.$count.'" >Page suivante</a></li>'."\n";
          echo '           <li><a href="'.LinkManager::GetInstance()->Generate().'&start='.(count($medias)-$count).'&count='.$count.'" >Dernière page</a></li>'."\n"; 
        }
        echo '          </ul>'."\n";
        
        
        echo '        </div>'."\n";
      }

  function PrintAlbumsPageBody()
  {
        foreach($this->childAlbumList as $album){
        echo '  <div class=album>'."\n";
        echo '  <p>Album <a href="'.LinkManager::GetInstance()->GeneratePath($album->GetPath()).'" >'.$album->GetName().'</a> ('.$album->GetDescription().')'.(LoginManager::GetInstance()->IsAccessAllowed($album)?'':' - Accès refusé').'</p>'."\n";
        echo '  </div>'."\n";
        }
  }

     
  function DisplaySource()
  {
    header( "Content-Type: text/plain" );
    $source = fopen("index.php","r");

    while ($ligne = fgets($source))
    {
      echo $ligne;
    }

    fclose($source);
  }

  function PrintLoginForm($loginFail)
  {
    echo '      <div  class="login-bloc">'."\n";
    echo '        <form action="'.LinkManager::GetInstance()->GenerateWant('login').'" method="post" >'."\n";
    echo '          <ul>'."\n";
    echo '            <li>Identifiant : <input name=login type=text /></li>'."\n";
    echo '            <li>Mot de passe : <input name=password type=password /></li>'."\n";
    echo '            <li><input type=submit value="Valider" /></li>'."\n";
    if($loginFail){
     echo '            <li class=error >Identifiant ou mot de passe incorrect. Accès refusé.</li>'."\n";
    }
    echo '          </ul>'."\n";
    echo '        </form>'."\n";
    echo '      </div>'."\n";//div image
  }
  
  function PrintAccessRefusedPageBody()
  {
    echo '      <div  class="login-bloc">'."\n";
    echo '        <p>'."\n";
    echo '          Accès refusé pour l\'utilisateur « '.LoginManager::GetInstance()->GetCurrentLogin().' ». Essayer un autre compte ou contacter l\'administrateur.'."\n";
    echo '        </p>'."\n";
    echo '      </div>'."\n";//div image
  }
  
  function PrintHelpPageBody()
  {  
    echo '      <h1>Documentation - Shrew-gallery v'.Config::GetInstance()->version.'</h1>'."\n";
    echo '      <h2>Installation</h2>'."\n";
    echo '        <p>'."\n";
    echo '          Si vous êtes arrivé ici, c\'est que Shrew-gallery est déjà installé !'."\n";
    echo '        </p>'."\n";
  }
}

?>
