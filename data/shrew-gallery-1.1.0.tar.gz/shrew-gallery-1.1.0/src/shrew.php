<?php
//l Copyright (C) 2009 Frédéric Bertolus.
//l
//l This file is part of Shrew-gallery.
//l
//l   Shrew-gallery is free software: you can redistribute it and/or modify
//l   it under the terms of the GNU Affero General Public License as published by
//l   the Free Software Foundation, either version 3 of the License, or
//l   (at your option) any later version.
//l
//l   Shrew-gallery is distributed in the hope that it will be useful,
//l   but WITHOUT ANY WARRANTY; without even the implied warranty of
//l   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//l   GNU Affero General Public License for more details.
//l
//l   You should have received a copy of the GNU Affero General Public License
//l   along with Shrew-gallery.  If not, see <http://www.gnu.org/licenses/>.

class Shrew {
  function Run()
  {
  	//Load config
    Config::SetInstance(new Config());
    Config::GetInstance()->Load();
    
    $albumManager = new AlbumManager();      
    $album = new Album();
    $album->SetPath(Config::GetInstance()->GetPath());
    
    LinkManager::SetInstance(new LinkManager());
    LinkManager::GetInstance()->SetAlbum($album);
      
    
    $displayManager = new DisplayManager();
	  
    //Create Login Manager
    $loginManager = new LoginManager();
    LoginManager::SetInstance($loginManager);
    $loginManager->Load();
    $loginFail = false;
    if($loginManager->WantLogin())
    {
       $loginFail = !$loginManager->TryLogin();
       if(!$loginFail)
       {
         header('location: '.LinkManager::GetInstance()->Generate());
       }
    }
    
    if($loginManager->WantLogout())
    {
       $loginManager->Logout();
    }
    
    
    if(isset($_GET['want']) and $_GET['want']== 'logo')
    {
      $logo = new Logo();
      $logo->Generate();
      return;
    }
    elseif(isset($_GET['want']) and $_GET['want']== 'source')
    {
      $displayManager->DisplaySource();
    }
    elseif(isset($_GET['want']) and $_GET['want']== 'help')
    {
      $displayManager->DisplayHelpPage();
    }
    else 
    {
    
      
      if($loginManager->IsAccessAllowed($album)){
        $displayManager->DisplayImagesPage($album);
      }else{
        if($loginManager->IsLogged()){
          $displayManager->DisplayAccessRefusedPage($album);
        }else{
          $displayManager->DisplayLoginPage($album,$loginFail);
        }
      }
    }
    
  }
}

?>
